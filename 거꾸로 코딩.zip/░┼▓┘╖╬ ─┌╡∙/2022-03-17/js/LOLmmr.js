var lolmmr = prompt("당신의 mmr점수는? ", "0");

if (752<=lolmmr && 823>=lolmmr) {
    document.write("당신의 티어는 브론즈");}
else if (824<=lolmmr && 1200>=lolmmr){
    document.write("당신의 티어는 첼린저");}
else if (1201<=lolmmr && 1600>=lolmmr){
    document.write("당신의 티어는 골드");}
else if (1601<=lolmmr && 1900>=lolmmr){
    document.write("당신의 티어는 플레티넘");}
else if (1901<=lolmmr && 2000>=lolmmr){
    document.write("당신의 티어는 다이아");}
else if (2001<=lolmmr && 3500>=lolmmr){
    document.write("당신의 티어는 마스터");}
else if (3501<=lolmmr && 3600>=lolmmr){
    document.write("당신의 티어는 첼린저");}
else if (lolmmr <= 751){
        document.write("당신은 언랭!!!");}
else if (lolmmr > 3601){
    document.write("입력 범위를 초과함");}