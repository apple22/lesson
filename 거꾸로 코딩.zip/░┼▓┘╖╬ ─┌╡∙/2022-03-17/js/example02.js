var walkAmount = prompt("당신의 하루 걷는 양 ", "0");


if(walkAmount >= 10000){

    document.write ("매우 좋은 습관");
        
}else{
    document.write("조금 더 걸어보세요 !");

}   