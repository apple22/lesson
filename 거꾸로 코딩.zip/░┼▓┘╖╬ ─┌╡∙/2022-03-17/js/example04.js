var i=1;

 while(i<=10){
     if (i%2 == 0 && i%6 ==0){
     document.write(i,"<br/>");
 }

 ++i
 }