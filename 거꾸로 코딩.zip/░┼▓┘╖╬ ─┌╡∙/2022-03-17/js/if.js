var a = 10;

 if(a < 10){
    document.while ("참");

 }else{
    document.while ("거짓");
 }