var a = 5;
var b = 3;
var c = 3;

var d = a-b+c;

document.write("짱구가 가지고 있는 남아있는 사과의 갯수는? = ", d);

