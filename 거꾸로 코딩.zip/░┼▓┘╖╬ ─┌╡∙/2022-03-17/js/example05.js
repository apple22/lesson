var i= 20;

while(i>=10){
    if(i%2 == 0){
        document.write("<font color='blue'>"+i+"</font>","<br/>");
    }
    else{
        document.write("<font color='red'>"+i+"</font>","<br/>");
    }
    i--
}