
for(var i=0;i<=100;i++){
    if(i%5 == 0 && i%7 == 0){
        document.write("<font color='red'>"+i+"</font>","<br/>");
    }
    else{
        document.write("<font color='blue'>"+i+"</font>","<br/>");
    }
}